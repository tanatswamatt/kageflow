<?php
/**
 * Plugin Name: Kageflow Connect
 * Description: Shows your Kageflow stock on this WordPress site and sends every enquiry (car pages and Contact Form 7 forms) to Kageflow as a lead.
 * Version: 1.0.0
 * Author: Pretan Technologies
 * Author URI: https://www.kageflow.co.za
 * Requires PHP: 7.4
 * Requires at least: 5.8
 * License: GPLv2 or later
 * Text Domain: kageflow-connect
 */

if (!defined('ABSPATH')) {
    exit;
}

define('KAGEFLOW_VERSION', '1.0.0');

/* ------------------------------------------------------------------ settings */

function kageflow_opt($key, $default = '')
{
    $o = get_option('kageflow_settings', []);
    return isset($o[$key]) && $o[$key] !== '' ? $o[$key] : $default;
}

add_action('admin_menu', function () {
    add_options_page('Kageflow', 'Kageflow', 'manage_options', 'kageflow', 'kageflow_settings_page');
});

add_action('admin_init', function () {
    register_setting('kageflow', 'kageflow_settings', [
        'sanitize_callback' => function ($in) {
            $old = get_option('kageflow_settings', []);
            $out = [
                'app_url'    => esc_url_raw(rtrim(trim($in['app_url'] ?? 'https://app.kageflow.co.za'), '/')),
                'feed_url'   => esc_url_raw(trim($in['feed_url'] ?? '')),
                'whatsapp'   => preg_replace('/\D/', '', $in['whatsapp'] ?? ''),
                'accent'     => sanitize_hex_color($in['accent'] ?? '') ?: '#0b6b5f',
                'cf7'        => empty($in['cf7']) ? '' : '1',
                'consent'    => sanitize_text_field($in['consent'] ?? ''),
                'stock_page' => esc_url_raw(trim($in['stock_page'] ?? '')),
            ];
            // keep the saved key unless a new one is typed
            $key = trim($in['api_key'] ?? '');
            $out['api_key'] = $key !== '' ? sanitize_text_field($key) : ($old['api_key'] ?? '');
            delete_transient('kageflow_feed');
            return $out;
        },
    ]);
});

function kageflow_settings_page()
{
    if (!current_user_can('manage_options')) {
        return;
    }
    $test = null;
    if (isset($_GET['kf_test']) && check_admin_referer('kageflow_test')) {
        delete_transient('kageflow_feed');
        $feed = kageflow_feed(true);
        $test = is_wp_error($feed) ? ['error', $feed->get_error_message()] : ['ok', sprintf('Connected: %d cars in your Kageflow feed.', count($feed['vehicles'] ?? []))];
    }
    $last = get_option('kageflow_last_error');
    ?>
    <div class="wrap">
        <h1>Kageflow</h1>
        <p>Your stock comes from Kageflow, so a car you publish there appears here, and a car you reserve or sell comes off by itself. Enquiries from car pages and from your Contact Form 7 forms arrive in Kageflow as leads.</p>
        <?php if ($test): ?>
            <div class="notice notice-<?php echo $test[0] === 'ok' ? 'success' : 'error'; ?>"><p><?php echo esc_html($test[1]); ?></p></div>
        <?php endif; ?>
        <?php if ($last): ?>
            <div class="notice notice-warning"><p><strong>Last problem sending to Kageflow</strong> (<?php echo esc_html($last['at'] ?? ''); ?>): <?php echo esc_html($last['message'] ?? ''); ?>. The enquiry was emailed to the site admin instead.</p></div>
        <?php endif; ?>
        <form method="post" action="options.php">
            <?php settings_fields('kageflow'); ?>
            <table class="form-table" role="presentation">
                <tr><th scope="row"><label for="kf_app">Kageflow address</label></th>
                    <td><input id="kf_app" name="kageflow_settings[app_url]" type="url" class="regular-text" value="<?php echo esc_attr(kageflow_opt('app_url', 'https://app.kageflow.co.za')); ?>"></td></tr>
                <tr><th scope="row"><label for="kf_key">API key</label></th>
                    <td><input id="kf_key" name="kageflow_settings[api_key]" type="password" class="regular-text" autocomplete="off" placeholder="<?php echo kageflow_opt('api_key') ? 'Saved. Leave blank to keep it.' : 'kf_live_…'; ?>">
                    <p class="description">In Kageflow: Settings, Integrations, API keys. Create one called after this website.</p></td></tr>
                <tr><th scope="row"><label for="kf_feed">Stock feed link</label></th>
                    <td><input id="kf_feed" name="kageflow_settings[feed_url]" type="url" class="large-text" value="<?php echo esc_attr(kageflow_opt('feed_url')); ?>">
                    <p class="description">In Kageflow: Settings, Listings and leads, Stock feeds. Create a feed for <em>My website</em> and copy its link.</p></td></tr>
                <tr><th scope="row"><label for="kf_wa">WhatsApp number</label></th>
                    <td><input id="kf_wa" name="kageflow_settings[whatsapp]" type="text" class="regular-text" value="<?php echo esc_attr(kageflow_opt('whatsapp')); ?>" placeholder="27821234567">
                    <p class="description">International format, digits only. Each car gets a WhatsApp button that mentions its stock number, so the lead is linked to the car.</p></td></tr>
                <tr><th scope="row"><label for="kf_page">Stock page address</label></th>
                    <td><input id="kf_page" name="kageflow_settings[stock_page]" type="url" class="regular-text" value="<?php echo esc_attr(kageflow_opt('stock_page')); ?>" placeholder="<?php echo esc_attr(home_url('/used-cars/')); ?>">
                    <p class="description">The page where you put <code>[kageflow_stock]</code>. Used for links from <code>[kageflow_latest]</code>.</p></td></tr>
                <tr><th scope="row">Contact Form 7</th>
                    <td><label><input type="checkbox" name="kageflow_settings[cf7]" value="1" <?php checked(kageflow_opt('cf7'), '1'); ?>> Send every Contact Form 7 submission to Kageflow as a lead (the form's email still goes out as before)</label></td></tr>
                <tr><th scope="row"><label for="kf_consent">Consent wording</label></th>
                    <td><input id="kf_consent" name="kageflow_settings[consent]" type="text" class="large-text" value="<?php echo esc_attr(kageflow_opt('consent', 'I agree to be contacted about my enquiry')); ?>">
                    <p class="description">Shown as a tick box on car enquiry forms and recorded on the lead (POPIA).</p></td></tr>
                <tr><th scope="row"><label for="kf_accent">Button colour</label></th>
                    <td><input id="kf_accent" name="kageflow_settings[accent]" type="text" value="<?php echo esc_attr(kageflow_opt('accent', '#0b6b5f')); ?>" placeholder="#0b6b5f"></td></tr>
            </table>
            <?php submit_button(); ?>
        </form>
        <p><a class="button" href="<?php echo esc_url(wp_nonce_url(admin_url('options-general.php?page=kageflow&kf_test=1'), 'kageflow_test')); ?>">Test the stock feed</a></p>
        <h2>Shortcodes</h2>
        <p><code>[kageflow_stock]</code> on your Used Cars page: the full stock list with search and filters, and each car's page with photos, details, WhatsApp and an enquiry form.<br>
        Options: <code>condition="used"</code> or <code>condition="new"</code>, <code>per_page="24"</code>.</p>
        <p><code>[kageflow_latest count="6"]</code> on the home page: the newest cars.</p>
    </div>
    <?php
}

/* ------------------------------------------------------------------ the stock feed */

/** The feed, cached for 5 minutes. If Kageflow can't be reached, the last good copy is used. */
function kageflow_feed($fresh = false)
{
    $cached = $fresh ? false : get_transient('kageflow_feed');
    if (is_array($cached)) {
        return $cached;
    }
    $url = kageflow_opt('feed_url');
    if (!$url) {
        return new WP_Error('kageflow', 'Add your Kageflow stock feed link under Settings, Kageflow.');
    }
    $url = add_query_arg('format', 'json', $url);
    $res = wp_remote_get($url, ['timeout' => 10, 'headers' => ['Accept' => 'application/json']]);
    $code = is_wp_error($res) ? 0 : wp_remote_retrieve_response_code($res);
    $data = $code === 200 ? json_decode(wp_remote_retrieve_body($res), true) : null;
    if (!is_array($data) || !isset($data['vehicles'])) {
        $last = get_option('kageflow_feed_last');
        if (is_array($last)) {
            set_transient('kageflow_feed', $last, MINUTE_IN_SECONDS);
            return $last;
        }
        return new WP_Error('kageflow', $code === 404 ? 'The stock feed link is wrong or the feed was removed in Kageflow.' : 'Kageflow could not be reached.');
    }
    set_transient('kageflow_feed', $data, 5 * MINUTE_IN_SECONDS);
    update_option('kageflow_feed_last', $data, false);
    return $data;
}

function kageflow_money($amount, $currency)
{
    if ($amount === null || $amount === '') {
        return 'Price on request';
    }
    $n = number_format((float) $amount, 0, '.', ' ');
    $sym = ['ZAR' => 'R ', 'USD' => 'US$ ', 'ZWG' => 'ZiG ', 'BWP' => 'P ', 'NAD' => 'N$ '];
    return ($sym[$currency] ?? ($currency . ' ')) . $n;
}

function kageflow_title($v)
{
    return !empty($v['title']) ? $v['title'] : trim(implode(' ', array_filter([$v['year'] ?? '', $v['make'] ?? '', $v['model'] ?? '', $v['variant'] ?? ''])));
}

function kageflow_find($stock_no)
{
    $feed = kageflow_feed();
    if (is_wp_error($feed)) {
        return null;
    }
    foreach ($feed['vehicles'] as $v) {
        if (strcasecmp($v['stock_no'] ?? '', $stock_no) === 0) {
            return $v;
        }
    }
    return null;
}

function kageflow_wa_link($v = null)
{
    $n = kageflow_opt('whatsapp');
    if (!$n) {
        return '';
    }
    $text = $v ? sprintf("Hi, I'm interested in the %s (%s)", kageflow_title($v), $v['stock_no']) : 'Hi, I have a question about a car';
    return 'https://wa.me/' . $n . '?text=' . rawurlencode($text);
}

/* ------------------------------------------------------------------ front end */

add_action('wp_enqueue_scripts', function () {
    wp_register_style('kageflow', plugins_url('assets/kageflow.css', __FILE__), [], KAGEFLOW_VERSION);
    wp_add_inline_style('kageflow', '.kf{--kf-accent:' . esc_attr(kageflow_opt('accent', '#0b6b5f')) . '}');
});

// a car's page shows its own name in the browser tab and in search results
add_filter('document_title_parts', function ($parts) {
    if (!empty($_GET['car'])) {
        $v = kageflow_find(sanitize_text_field(wp_unslash($_GET['car'])));
        if ($v) {
            $parts['title'] = kageflow_title($v);
        }
    }
    return $parts;
});

add_shortcode('kageflow_latest', function ($atts) {
    $a = shortcode_atts(['count' => 6], $atts);
    wp_enqueue_style('kageflow');
    $feed = kageflow_feed();
    if (is_wp_error($feed)) {
        return current_user_can('manage_options') ? '<p class="kf-note">' . esc_html($feed->get_error_message()) . '</p>' : '';
    }
    $cars = array_slice($feed['vehicles'], 0, max(1, (int) $a['count']));
    $base = kageflow_opt('stock_page') ?: get_permalink();
    $out = '<div class="kf"><div class="kf-grid">';
    foreach ($cars as $v) {
        $out .= kageflow_card($v, $base);
    }
    return $out . '</div></div>';
});

add_shortcode('kageflow_stock', function ($atts) {
    $a = shortcode_atts(['condition' => '', 'per_page' => 24], $atts);
    wp_enqueue_style('kageflow');
    $feed = kageflow_feed();
    if (is_wp_error($feed)) {
        return '<div class="kf"><p class="kf-note">' . esc_html(current_user_can('manage_options') ? $feed->get_error_message() : 'Our stock list is being updated. Please call or WhatsApp us.') . '</p></div>';
    }
    $base = get_permalink();
    if (!empty($_GET['car'])) {
        $v = kageflow_find(sanitize_text_field(wp_unslash($_GET['car'])));
        return $v ? kageflow_detail($v, $base) : '<div class="kf"><p class="kf-note">That car has been sold or is no longer listed. <a href="' . esc_url($base) . '">See all our cars</a>.</p></div>';
    }

    $cars = $feed['vehicles'];
    if ($a['condition'] === 'used' || $a['condition'] === 'new') {
        $cars = array_values(array_filter($cars, function ($v) use ($a) { return ($v['condition'] ?? '') === $a['condition']; }));
    }
    $makes = array_values(array_unique(array_filter(array_map(function ($v) { return $v['make'] ?? ''; }, $cars))));
    sort($makes);

    $q = isset($_GET['kq']) ? sanitize_text_field(wp_unslash($_GET['kq'])) : '';
    $make = isset($_GET['kmake']) ? sanitize_text_field(wp_unslash($_GET['kmake'])) : '';
    $max = isset($_GET['kmax']) ? (float) $_GET['kmax'] : 0;
    $sort = isset($_GET['ksort']) ? sanitize_key($_GET['ksort']) : '';
    $cars = array_values(array_filter($cars, function ($v) use ($q, $make, $max) {
        if ($make !== '' && strcasecmp($v['make'] ?? '', $make) !== 0) return false;
        if ($max > 0 && (float) ($v['price'] ?? 0) > $max) return false;
        if ($q !== '' && stripos(kageflow_title($v) . ' ' . ($v['stock_no'] ?? ''), $q) === false) return false;
        return true;
    }));
    if ($sort === 'low' || $sort === 'high') {
        usort($cars, function ($x, $y) use ($sort) { $d = (float) ($x['price'] ?? 0) <=> (float) ($y['price'] ?? 0); return $sort === 'low' ? $d : -$d; });
    } elseif ($sort === 'km') {
        usort($cars, function ($x, $y) { return (int) ($x['mileage_km'] ?? PHP_INT_MAX) <=> (int) ($y['mileage_km'] ?? PHP_INT_MAX); });
    } elseif ($sort === 'year') {
        usort($cars, function ($x, $y) { return (int) ($y['year'] ?? 0) <=> (int) ($x['year'] ?? 0); });
    }
    $per = max(1, (int) $a['per_page']);
    $page = max(1, (int) ($_GET['kpage'] ?? 1));
    $pages = max(1, (int) ceil(count($cars) / $per));
    $shown = array_slice($cars, ($page - 1) * $per, $per);

    ob_start(); ?>
    <div class="kf">
        <form class="kf-filters" method="get" action="<?php echo esc_url($base); ?>">
            <input type="search" name="kq" value="<?php echo esc_attr($q); ?>" placeholder="Search make, model or stock number" aria-label="Search">
            <select name="kmake" aria-label="Make"><option value="">All makes</option>
                <?php foreach ($makes as $m): ?><option <?php selected($make, $m); ?>><?php echo esc_html($m); ?></option><?php endforeach; ?>
            </select>
            <select name="kmax" aria-label="Maximum price"><option value="">Any price</option>
                <?php foreach ([150000, 250000, 350000, 500000, 750000, 1000000] as $p): ?><option value="<?php echo (int) $p; ?>" <?php selected((int) $max, $p); ?>>Up to <?php echo esc_html(kageflow_money($p, $cars[0]['currency'] ?? 'ZAR')); ?></option><?php endforeach; ?>
            </select>
            <select name="ksort" aria-label="Sort"><option value="">Newest first</option><option value="low" <?php selected($sort, 'low'); ?>>Price: low to high</option><option value="high" <?php selected($sort, 'high'); ?>>Price: high to low</option><option value="km" <?php selected($sort, 'km'); ?>>Lowest mileage</option><option value="year" <?php selected($sort, 'year'); ?>>Newest year</option></select>
            <button type="submit">Search</button>
        </form>
        <p class="kf-count"><?php echo esc_html(sprintf(_n('%d car', '%d cars', count($cars)), count($cars))); ?></p>
        <?php if (!$shown): ?><p class="kf-note">No cars match. Try fewer filters, or WhatsApp us what you're looking for.</p><?php endif; ?>
        <div class="kf-grid"><?php foreach ($shown as $v) echo kageflow_card($v, $base); // phpcs:ignore ?></div>
        <?php if ($pages > 1): ?><nav class="kf-pages"><?php for ($i = 1; $i <= $pages; $i++): ?>
            <a class="<?php echo $i === $page ? 'is-current' : ''; ?>" href="<?php echo esc_url(add_query_arg('kpage', $i)); ?>"><?php echo (int) $i; ?></a>
        <?php endfor; ?></nav><?php endif; ?>
    </div>
    <?php
    return ob_get_clean();
});

function kageflow_card($v, $base)
{
    $url = add_query_arg('car', rawurlencode($v['stock_no'] ?? ''), $base);
    $img = $v['photos'][0] ?? '';
    $meta = array_filter([
        isset($v['mileage_km']) && $v['mileage_km'] !== null ? number_format((float) $v['mileage_km'], 0, '.', ' ') . ' km' : '',
        $v['transmission'] ?? '', $v['fuel_type'] ?? '',
    ]);
    return '<a class="kf-card" href="' . esc_url($url) . '">'
        . ($img ? '<img src="' . esc_url($img) . '" alt="' . esc_attr(kageflow_title($v)) . '" loading="lazy">' : '<span class="kf-noimg">Photos coming soon</span>')
        . (($v['status'] ?? '') === 'reserved' ? '<span class="kf-badge">Reserved</span>' : '')
        . '<span class="kf-card-body"><span class="kf-card-title">' . esc_html(kageflow_title($v)) . '</span>'
        . '<span class="kf-card-meta">' . esc_html(implode(' · ', $meta)) . '</span>'
        . '<span class="kf-price">' . esc_html(kageflow_money($v['price'] ?? null, $v['currency'] ?? 'ZAR')) . '</span></span></a>';
}

function kageflow_detail($v, $base)
{
    $photos = array_values(array_filter((array) ($v['photos'] ?? [])));
    $sent = isset($_GET['kf_sent']);
    $err = isset($_GET['kf_error']) ? sanitize_text_field(wp_unslash($_GET['kf_error'])) : '';
    $specs = [
        'Year' => $v['year'] ?? '', 'Mileage' => isset($v['mileage_km']) && $v['mileage_km'] !== null ? number_format((float) $v['mileage_km'], 0, '.', ' ') . ' km' : '',
        'Gearbox' => $v['transmission'] ?? '', 'Fuel' => $v['fuel_type'] ?? '', 'Body' => $v['body_type'] ?? '', 'Colour' => $v['colour'] ?? '',
        'Condition' => ucfirst($v['condition'] ?? ''), 'Location' => $v['location'] ?? '', 'Stock number' => $v['stock_no'] ?? '',
    ];
    $wa = kageflow_wa_link($v);
    ob_start(); ?>
    <div class="kf kf-detail">
        <p><a href="<?php echo esc_url($base); ?>">&larr; All cars</a></p>
        <div class="kf-detail-grid">
            <div>
                <?php if ($photos): ?>
                    <img class="kf-main" id="kf-main" src="<?php echo esc_url($photos[0]); ?>" alt="<?php echo esc_attr(kageflow_title($v)); ?>">
                    <?php if (count($photos) > 1): ?><div class="kf-thumbs"><?php foreach ($photos as $i => $p): ?>
                        <button type="button" onclick="document.getElementById('kf-main').src=this.dataset.src" data-src="<?php echo esc_url($p); ?>"><img src="<?php echo esc_url($p); ?>" alt="Photo <?php echo (int) $i + 1; ?>" loading="lazy"></button>
                    <?php endforeach; ?></div><?php endif; ?>
                <?php else: ?><div class="kf-noimg kf-main">Photos coming soon</div><?php endif; ?>
                <?php if (!empty($v['description'])): ?><div class="kf-desc"><?php echo wpautop(esc_html($v['description'])); ?></div><?php endif; ?>
                <?php if (!empty($v['features'])): ?><ul class="kf-features"><?php foreach ((array) $v['features'] as $f): ?><li><?php echo esc_html($f); ?></li><?php endforeach; ?></ul><?php endif; ?>
            </div>
            <aside>
                <h2 class="kf-title"><?php echo esc_html(kageflow_title($v)); ?></h2>
                <p class="kf-price kf-price-lg"><?php echo esc_html(kageflow_money($v['price'] ?? null, $v['currency'] ?? 'ZAR')); ?></p>
                <?php if (($v['status'] ?? '') === 'reserved'): ?><p class="kf-badge kf-badge-inline">Reserved: ask us to join the waiting list</p><?php endif; ?>
                <table class="kf-specs"><?php foreach ($specs as $k => $val) if ($val !== '' && $val !== null): ?><tr><th><?php echo esc_html($k); ?></th><td><?php echo esc_html($val); ?></td></tr><?php endif; ?></table>
                <?php if ($wa): ?><a class="kf-btn kf-wa" href="<?php echo esc_url($wa); ?>" target="_blank" rel="noopener">WhatsApp us about this car</a><?php endif; ?>
                <?php if ($sent): ?>
                    <p class="kf-ok">Thank you. We've got your enquiry and will be in touch shortly.</p>
                <?php else: ?>
                    <?php if ($err): ?><p class="kf-error"><?php echo esc_html($err); ?></p><?php endif; ?>
                    <form class="kf-form" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                        <input type="hidden" name="action" value="kageflow_enquiry">
                        <input type="hidden" name="stock_no" value="<?php echo esc_attr($v['stock_no'] ?? ''); ?>">
                        <input type="hidden" name="back" value="<?php echo esc_url(add_query_arg('car', rawurlencode($v['stock_no'] ?? ''), $base)); ?>">
                        <?php wp_nonce_field('kageflow_enquiry', 'kf_nonce'); ?>
                        <p class="kf-hp" aria-hidden="true"><label>Leave empty<input type="text" name="kf_website" tabindex="-1" autocomplete="off"></label></p>
                        <label>Name<input type="text" name="kf_name" required maxlength="120" autocomplete="name"></label>
                        <label>Phone<input type="tel" name="kf_phone" maxlength="40" autocomplete="tel"></label>
                        <label>Email<input type="email" name="kf_email" maxlength="200" autocomplete="email"></label>
                        <label>Message<textarea name="kf_message" rows="3" maxlength="2000">Is the <?php echo esc_textarea(kageflow_title($v)); ?> still available?</textarea></label>
                        <label class="kf-check"><input type="checkbox" name="kf_consent" value="1" required> <?php echo esc_html(kageflow_opt('consent', 'I agree to be contacted about my enquiry')); ?></label>
                        <button type="submit" class="kf-btn">Send enquiry</button>
                    </form>
                <?php endif; ?>
            </aside>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

/* ------------------------------------------------------------------ leads to Kageflow */

/** Send one lead. Never throws; if Kageflow can't take it, the site admin gets it by email so nothing is lost. */
function kageflow_send_lead(array $lead)
{
    $key = kageflow_opt('api_key');
    $app = kageflow_opt('app_url', 'https://app.kageflow.co.za');
    $ok = false;
    $message = 'No API key saved';
    if ($key) {
        $res = wp_remote_post($app . '/api/v1/leads', [
            'timeout' => 8,
            'headers' => ['Authorization' => 'Bearer ' . $key, 'Content-Type' => 'application/json'],
            'body'    => wp_json_encode($lead),
        ]);
        $code = is_wp_error($res) ? 0 : wp_remote_retrieve_response_code($res);
        $ok = $code >= 200 && $code < 300;
        if (!$ok) {
            $body = is_wp_error($res) ? $res->get_error_message() : wp_remote_retrieve_body($res);
            $json = json_decode($body, true);
            $message = 'Kageflow answered ' . $code . ': ' . (is_array($json) && isset($json['error']) ? $json['error'] : substr((string) $body, 0, 200));
        }
    }
    if (!$ok) {
        update_option('kageflow_last_error', ['at' => current_time('mysql'), 'message' => $message], false);
        $lines = [];
        foreach ($lead as $k => $val) {
            if (is_scalar($val) && $val !== '') $lines[] = ucfirst(str_replace('_', ' ', $k)) . ': ' . $val;
        }
        wp_mail(get_option('admin_email'), 'Website enquiry (not delivered to Kageflow)', implode("\n", $lines) . "\n\nProblem: " . $message);
    }
    return $ok;
}

function kageflow_split_name($name)
{
    $name = trim(preg_replace('/\s+/', ' ', (string) $name));
    $parts = explode(' ', $name, 2);
    return [$parts[0] ?? '', $parts[1] ?? ''];
}

// enquiry form on a car's page
add_action('admin_post_nopriv_kageflow_enquiry', 'kageflow_handle_enquiry');
add_action('admin_post_kageflow_enquiry', 'kageflow_handle_enquiry');
function kageflow_handle_enquiry()
{
    $back = isset($_POST['back']) ? esc_url_raw(wp_unslash($_POST['back'])) : home_url('/');
    $back = wp_validate_redirect($back, home_url('/'));
    $fail = function ($msg) use ($back) {
        wp_safe_redirect(add_query_arg('kf_error', rawurlencode($msg), remove_query_arg(['kf_sent', 'kf_error'], $back)));
        exit;
    };
    if (!isset($_POST['kf_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['kf_nonce'])), 'kageflow_enquiry')) {
        $fail('Your session timed out. Please send the form again.');
    }
    if (!empty($_POST['kf_website'])) { // filled in by bots only
        wp_safe_redirect(add_query_arg('kf_sent', '1', $back));
        exit;
    }
    $ip = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : '';
    $throttle = 'kf_t_' . md5($ip);
    if (get_transient($throttle)) {
        $fail('Please wait a few seconds before sending another enquiry.');
    }
    set_transient($throttle, 1, 20);

    $name = sanitize_text_field(wp_unslash($_POST['kf_name'] ?? ''));
    $phone = sanitize_text_field(wp_unslash($_POST['kf_phone'] ?? ''));
    $email = sanitize_email(wp_unslash($_POST['kf_email'] ?? ''));
    $msg = sanitize_textarea_field(wp_unslash($_POST['kf_message'] ?? ''));
    $stock = sanitize_text_field(wp_unslash($_POST['stock_no'] ?? ''));
    if ($name === '') $fail('Please enter your name.');
    if ($phone === '' && $email === '') $fail('Please enter a phone number or email so we can reply.');
    if (empty($_POST['kf_consent'])) $fail('Please tick the box so we may contact you.');

    $v = $stock ? kageflow_find($stock) : null;
    [$first, $last] = kageflow_split_name($name);
    kageflow_send_lead([
        'external_ref'    => 'wp-' . wp_generate_uuid4(),
        'first_name'      => $first,
        'last_name'       => $last,
        'email'           => $email,
        'phone'           => $phone,
        'stock_no'        => $stock,
        'interest'        => $v ? kageflow_title($v) . ' (' . $stock . ')' : $stock,
        'estimated_value' => $v['price'] ?? null,
        'currency'        => $v['currency'] ?? null,
        'message'         => $msg,
        'source'          => 'web_form',
        'source_detail'   => wp_parse_url(home_url(), PHP_URL_HOST) . ' · car page',
        'consent'         => true,
        'consent_text'    => kageflow_opt('consent', 'I agree to be contacted about my enquiry'),
    ]);
    wp_safe_redirect(add_query_arg('kf_sent', '1', remove_query_arg('kf_error', $back)));
    exit;
}

// every Contact Form 7 form (contact, sell your car, finance) also lands in Kageflow
add_action('wpcf7_mail_sent', function ($form) {
    if (kageflow_opt('cf7') !== '1' || !class_exists('WPCF7_Submission')) {
        return;
    }
    $sub = WPCF7_Submission::get_instance();
    if (!$sub) {
        return;
    }
    $data = $sub->get_posted_data();
    $pick = function (array $keys) use (&$data) {
        foreach ($data as $k => $val) {
            $kk = strtolower((string) $k);
            foreach ($keys as $want) {
                if ($kk === $want || strpos($kk, $want) !== false) {
                    $val = is_array($val) ? implode(', ', $val) : (string) $val;
                    if (trim($val) !== '') {
                        unset($data[$k]);
                        return trim($val);
                    }
                }
            }
        }
        return '';
    };
    $first = $pick(['first-name', 'first_name', 'firstname', 'name-first']);
    $last = $pick(['last-name', 'last_name', 'lastname', 'surname']);
    $full = ($first === '' && $last === '') ? $pick(['your-name', 'full-name', 'fullname', 'name']) : '';
    if ($full !== '') {
        [$first, $last] = kageflow_split_name($full);
    }
    $email = $pick(['your-email', 'email', 'e-mail']);
    $phone = $pick(['your-phone', 'phone', 'tel', 'cell', 'mobile', 'whatsapp', 'number']);
    $subject = $pick(['your-subject', 'subject']);
    $message = $pick(['your-message', 'message', 'comments', 'enquiry', 'inquiry']);
    $consent = $pick(['acceptance', 'consent', 'agree', 'popia']) !== '';
    // everything else on the form (make, model, year, mileage of a car they want to sell...) goes into the message
    $extra = [];
    foreach ($data as $k => $val) {
        if (strpos((string) $k, '_') === 0) continue;
        $val = is_array($val) ? implode(', ', $val) : (string) $val;
        if (trim($val) !== '') $extra[] = ucfirst(str_replace(['-', '_'], ' ', (string) $k)) . ': ' . $val;
    }
    if ($first === '' && $last === '') {
        $first = $email !== '' ? strstr($email, '@', true) : 'Website visitor';
    }
    if ($email === '' && $phone === '') {
        return; // Kageflow needs a way to reply; the form's own email still went out
    }
    $page = method_exists($sub, 'get_meta') ? (string) $sub->get_meta('url') : '';
    kageflow_send_lead([
        'external_ref'  => 'wp-cf7-' . wp_generate_uuid4(),
        'first_name'    => $first,
        'last_name'     => $last,
        'email'         => $email,
        'phone'         => $phone,
        'subject'       => $subject !== '' ? $subject : $form->title(),
        'interest'      => $form->title(),
        'message'       => trim($message . ($extra ? "\n\n" . implode("\n", $extra) : '')),
        'source'        => 'web_form',
        'source_detail' => substr(wp_parse_url(home_url(), PHP_URL_HOST) . ' · ' . $form->title() . ($page ? ' · ' . $page : ''), 0, 200),
        'consent'       => $consent,
        'consent_text'  => $consent ? 'Ticked on the website form: ' . $form->title() : '',
    ]);
});
