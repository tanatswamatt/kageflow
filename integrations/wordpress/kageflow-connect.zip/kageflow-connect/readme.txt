=== Kageflow Connect ===
Contributors: pretantechnologies
Requires at least: 5.8
Requires PHP: 7.4
Stable tag: 1.3.0
License: GPLv2 or later

Shows your Kageflow stock on your WordPress site and sends every enquiry to Kageflow as a lead.

== Description ==
* Every Formidable Forms and Contact Form 7 entry is also sent to Kageflow as a lead. Your pages, forms and emails don't change.
* [kageflow_stock] lists your published Kageflow cars with search and filters, and gives each car its own page with photos, details, a WhatsApp button and an enquiry form.
* [kageflow_latest count="6"] shows your newest cars, for the home page.
* [kageflow_car_request] lets a customer paste a link to a car on AutoTrader, Cars.co.za or any site, with their enquiry. No stock feed needed.
* Links typed into any Contact Form 7 form are kept on the lead, and the car is read from the link.
* Cars you reserve or sell in Kageflow come off the site within 5 minutes.
* Enquiries from car pages, and from any Contact Form 7 form, arrive in Kageflow as leads, linked to the car when there is one. If Kageflow can't be reached, the enquiry is emailed to the site admin so nothing is lost.

== Installation ==
1. Plugins, Add New, Upload Plugin: choose kageflow-connect.zip, Install, Activate.
2. Settings, Kageflow: paste the API key and the stock feed link from Kageflow, add your WhatsApp number, tick Contact Form 7, Save.
3. Click Test the stock feed.
4. Put [kageflow_stock] on your Used Cars page.
